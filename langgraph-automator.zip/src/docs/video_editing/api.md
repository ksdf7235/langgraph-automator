# Video Editing API 명세

## Public 함수

### `apply_ken_burns_effect()` - Ken Burns 효과 적용
### `create_video_clip_from_frames()` - 프레임 시퀀스로 비디오 클립 생성
### `create_video_clip()` - 이미지로 비디오 클립 생성
### `compose_video()` - 모든 장면 결합하여 최종 비디오 생성
### `node_video_editor()` - LangGraph 노드 함수

