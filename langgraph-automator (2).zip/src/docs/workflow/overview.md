# Workflow 기능 개요

## 목적
LangGraph를 사용하여 비디오 생성 워크플로우를 정의하고 관리합니다.

## 스코프
- LangGraph StateGraph 구성
- 노드 등록 및 엣지 연결
- 재시도 로직 데코레이터
- 캐싱 로직 데코레이터
- 상태 관리

## 워크플로우 단계
1. script_writer - 대본 작성
2. audio_generator - 오디오 생성
3. visual_generator - 이미지 생성
4. motion_generator - 모션 생성
5. video_editor - 비디오 편집

